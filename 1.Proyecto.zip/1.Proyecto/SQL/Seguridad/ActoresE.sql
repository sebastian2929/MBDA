/*-----------------------PA_REPRESENTANTE_EMPRESA------------------------------*/
CREATE OR REPLACE PACKAGE PA_ROL_REPRESENTANTE_EMPRESA IS
    PROCEDURE  ad_evento(xIDEvento IN Varchar, xNombreEvento IN Varchar, xFechaInicio IN Date, xFechaFin IN Date, xDescripcion IN Varchar, xPremio IN Varchar, xEquipoGanador IN Varchar, xMaxEquipos IN Number, xMinEquipos IN Number, xMaxRangoEquipo IN Number, xMinRangoEquipo IN Number);
    PROCEDURE ad_juego(xIDCatalogo IN Varchar, xGeneroJuego IN Varchar, xEdadMinima IN Varchar, xDescripcion IN Varchar, xIDRepresentante IN Varchar);
    PROCEDURE mo_evento(xIDEvento IN Varchar, xNombreEvento IN Varchar, xFechaInicio IN Date, xFechaFin IN Date, xDescripcion IN Varchar, xPremio IN Varchar, xEquipoGanador IN Varchar, xMaxEquipos IN Number, xMinEquipos IN Number, xMaxRangoEquipo IN Number, xMinRangoEquipo IN Number);
END PA_ROL_REPRESENTANTE_EMPRESA;
/
/*-----------------------PA_LIDER------------------------------*/
CREATE OR REPLACE PACKAGE PA_ROL_LIDER IS
    PROCEDURE ad_grupo(xIdGrupo IN Varchar, xNombreGrupo IN Varchar);
    PROCEDURE mo_grupo(xIdGrupo IN Varchar, xNombreGrupo IN Varchar);
    PROCEDURE el_grupo(xIdGrupo IN Number);
    PROCEDURE ad_evento(xIDEvento IN Varchar, xNombreEvento IN Varchar, xFechaInicio IN Date, xFechaFin IN Date, xDescripcion IN Varchar, xPremio IN Varchar, xEquipoGanador IN Varchar, xMaxEquipos IN Number, xMinEquipos IN Number, xMaxRangoEquipo IN Number, xMinRangoEquipo IN Number);
    PROCEDURE mo_evento(xIDEvento IN Varchar, xNombreEvento IN Varchar, xFechaInicio IN Date, xFechaFin IN Date, xDescripcion IN Varchar, xPremio IN Varchar, xEquipoGanador IN Varchar, xMaxEquipos IN Number, xMinEquipos IN Number, xMaxRangoEquipo IN Number, xMinRangoEquipo IN Number);
    PROCEDURE ad_notificacionEvendto(xIDNotificacion IN Varchar, xDescripcion IN Varchar, xFechaEnvio IN Date, xCorreoLider IN Varchar, xIDLider IN Varchar, xIDGrupo IN Varchar, xIDEvento IN Varchar);
    FUNCTION  co_grupo RETURN SYS_REFCURSOR;
END PA_ROL_LIDER;
/
/*-----------------------PA_JUGADOR------------------------------*/
CREATE OR REPLACE PACKAGE PA_JUGADOR IS
    PROCEDURE ad_juego(xIDCatalogo IN Varchar, xGeneroJuego IN Varchar, xEdadMinima IN Number, xDescripcion IN Varchar, xIDRepresentante IN Varchar);
    PROCEDURE ad_dispositivo(xIDDispositivo IN Varchar, xDispositivo IN Varchar);
    PROCEDURE el_dispositivo(xIDDispositivo IN Varchar);
    PROCEDURE ad_registro(xIDRegistro IN Varchar, xNumeroDocumento IN Varchar, xTipoDocumento IN Varchar, xNombre IN Varchar, xApellido IN Varchar, xGenero IN Varchar, xCodigoPostal IN Varchar);
    PROCEDURE mo_registro(xIDRegistro IN Varchar, xNumeroDocumento IN Varchar, xTipoDocumento IN Varchar, xNombre IN Varchar, xApellido IN Varchar, xGenero IN Varchar, xCodigoPostal IN Varchar);
    PROCEDURE ad_lider(xIDLider IN Varchar, xInicioLider IN Date);
    FUNCTION  co_dispositivos RETURN SYS_REFCURSOR;
    FUNCTION  co_masJugado RETURN SYS_REFCURSOR;
    FUNCTION  co_catalogo RETURN SYS_REFCURSOR;
    FUNCTION  co_gruposRegion RETURN SYS_REFCURSOR;
    FUNCTION  co_juegoMayorPuntaje RETURN SYS_REFCURSOR;
    FUNCTION  co_ganadorEvento RETURN SYS_REFCURSOR;
    FUNCTION  co_rangoGrupo RETURN SYS_REFCURSOR;
    FUNCTION  co_descripcionGrupo RETURN SYS_REFCURSOR;
    FUNCTION  co_jugadorCercanos RETURN SYS_REFCURSOR;
    FUNCTION  co_eventosGratis RETURN SYS_REFCURSOR;
    FUNCTION  co_rangoJugador RETURN SYS_REFCURSOR;
    FUNCTION  co_notificacionEvento RETURN SYS_REFCURSOR;
END PA_JUGADOR;
/
/*-----------------------PA_EMPRESA------------------------------*/
CREATE OR REPLACE PACKAGE PA_ROL_EMPRESA IS
    PROCEDURE ad_representante(xIDRepresentante IN Varchar, xNumeroDocumento IN Varchar, xTipoDocumento IN Varchar, xNombre IN Varchar, xApellido IN Varchar);
    FUNCTION  co_catalogo RETURN SYS_REFCURSOR;
    FUNCTION  co_gruposRegion RETURN SYS_REFCURSOR;
    FUNCTION  co_juegoMayorPuntaje RETURN SYS_REFCURSOR;
    FUNCTION  co_ganadorEvento RETURN SYS_REFCURSOR;
    FUNCTION  co_masJugado RETURN SYS_REFCURSOR;
END PA_ROL_EMPRESA;
/
/*-----------------------PA_MODERADOR_TGAME------------------------------*/
CREATE OR REPLACE PACKAGE PA_MODERADOR_TGAME IS
    PROCEDURE el_juegosCatalgo(xNombre IN Varchar, IDCatalogo IN Varchar);
    PROCEDURE el_eventos(xIDEvento IN Varchar, xNombreEvento IN Varchar);
END PA_MODERADOR_TGAME;
/
/*-----------------------PA_GERENTE_TGAME------------------------------*/
CREATE OR REPLACE PACKAGE PA_GERENTE_TGAME IS
    FUNCTION  co_juegosMejorPunteados RETURN SYS_REFCURSOR;
    FUNCTION  co_juegosPeorPunteados RETURN SYS_REFCURSOR; 
    FUNCTION  co_catidadUsuarios RETURN SYS_REFCURSOR;
    FUNCTION  co_eventosNoGratuitos RETURN SYS_REFCURSOR;
    FUNCTION  co_dispositivoUsuario RETURN SYS_REFCURSOR;
    FUNCTION  co_promedioEdad RETURN SYS_REFCURSOR;
    FUNCTION  co_regionesActivas RETURN SYS_REFCURSOR;
    FUNCTION  co_juegoEnEventos RETURN SYS_REFCURSOR;
    FUNCTION  co_masGruposRegion RETURN SYS_REFCURSOR;
    FUNCTION  co_cantidadEventosRepresentante RETURN SYS_REFCURSOR;
END PA_GERENTE_TGAME;
/


