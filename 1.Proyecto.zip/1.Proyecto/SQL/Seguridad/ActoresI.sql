/*-----------------------PA_REPRESENTANTE_EMPRESA------------------------------*/
CREATE OR REPLACE PACKAGE PA_ROL_REPRESENTANTE_EMPRESA IS
    PROCEDURE  ad_evento(xIDEvento IN Varchar, xNombreEvento IN Varchar, xFechaInicio IN Date, xFechaFin IN Date, xDescripcion IN Varchar, xPremio IN Varchar, xEquipoGanador IN Varchar, xMaxEquipos IN Number, xMinEquipos IN Number, xMaxRangoEquipo IN Number, xMinRangoEquipo IN Number);
    BEGIN
    END;
    PROCEDURE ad_juego(xIDCatalogo IN Varchar, xGeneroJuego IN Varchar, xEdadMinima IN Varchar, xDescripcion IN Varchar, xIDRepresentante IN Varchar);
    BEGIN
    END;
    PROCEDURE mo_evento(xIDEvento IN Varchar, xNombreEvento IN Varchar, xFechaInicio IN Date, xFechaFin IN Date, xDescripcion IN Varchar, xPremio IN Varchar, xEquipoGanador IN Varchar, xMaxEquipos IN Number, xMinEquipos IN Number, xMaxRangoEquipo IN Number, xMinRangoEquipo IN Number);
    BEGIN
    END;
END PA_ROL_REPRESENTANTE_EMPRESA;
/
/*-----------------------PA_LIDER------------------------------*/
CREATE OR REPLACE PACKAGE PA_LIDER IS
    PROCEDURE ad_grupo(xIdGrupo IN Varchar, xNombreGrupo IN Varchar);
    BEGIN
    END;
    PROCEDURE mo_grupo(xIdGrupo IN Varchar, xNombreGrupo IN Varchar);
    BEGIN
    END;
    PROCEDURE el_grupo(xIdGrupo IN Number);
    BEGIN
    END;
    PROCEDURE ad_evento(xIDEvento IN Varchar, xNombreEvento IN Varchar, xFechaInicio IN Date, xFechaFin IN Date, xDescripcion IN Varchar, xPremio IN Varchar, xEquipoGanador IN Varchar, xMaxEquipos IN Number, xMinEquipos IN Number, xMaxRangoEquipo IN Number, xMinRangoEquipo IN Number);
    BEGIN
    END;
    PROCEDURE mo_evento(xIDEvento IN Varchar, xNombreEvento IN Varchar, xFechaInicio IN Date, xFechaFin IN Date, xDescripcion IN Varchar, xPremio IN Varchar, xEquipoGanador IN Varchar, xMaxEquipos IN Number, xMinEquipos IN Number, xMaxRangoEquipo IN Number, xMinRangoEquipo IN Number);
    BEGIN
    END;
    PROCEDURE ad_notificacionEvendto(xIDNotificacion IN Varchar, xDescripcion IN Varchar, xFechaEnvio IN Date, xCorreoLider IN Varchar, xIDLider IN Varchar, xIDGrupo IN Varchar, xIDEvento IN Varchar);
    BEGIN
    END;
    FUNCTION  co_grupo RETURN SYS_REFCURSOR;
    BEGIN
    END;
END PA_LIDER;
/
/*-----------------------PA_Jugador------------------------------*/
CREATE OR REPLACE PACKAGE PA_Jugador IS
    PROCEDURE ad_juego(xIDCatalogo IN Varchar, xGeneroJuego IN Varchar, xEdadMinima IN Number, xDescripcion IN Varchar, xIDRepresentante IN Varchar);
    BEGIN
    END;
    PROCEDURE ad_dispositivo(xIDDispositivo IN Varchar, xDispositivo IN Varchar);
    BEGIN
    END;
    PROCEDURE el_dispositivo(xIDDispositivo IN Varchar);
    BEGIN
    END;
    PROCEDURE ad_registro(xIDRegistro IN Varchar, xNumeroDocumento IN Varchar, xTipoDocumento IN Varchar, xNombre IN Varchar, xApellido IN Varchar, xGenero IN Varchar, xCodigoPostal IN Varchar);
    BEGIN
    END;
    PROCEDURE mo_registro(xIDRegistro IN Varchar, xNumeroDocumento IN Varchar, xTipoDocumento IN Varchar, xNombre IN Varchar, xApellido IN Varchar, xGenero IN Varchar, xCodigoPostal IN Varchar);
    BEGIN
    END;
    PROCEDURE ad_lider(xIDLider IN Varchar, xInicioLider IN Date);
    BEGIN
    END;
    FUNCTION  co_dispositivos RETURN SYS_REFCURSOR;
    BEGIN
    END;
    FUNCTION  co_masJugado RETURN SYS_REFCURSOR;
    BEGIN
    END;
    FUNCTION  co_catalogo RETURN SYS_REFCURSOR;
    BEGIN
    END;
    FUNCTION  co_gruposRegion RETURN SYS_REFCURSOR;
    BEGIN
    END;
    FUNCTION  co_juegoMayorPuntaje RETURN SYS_REFCURSOR;
    BEGIN
    END;
    FUNCTION  co_ganadorEvento RETURN SYS_REFCURSOR;
    BEGIN
    END;
    FUNCTION  co_rangoGrupo RETURN SYS_REFCURSOR;
    BEGIN
    END;
    FUNCTION  co_descripcionGrupo RETURN SYS_REFCURSOR;
    BEGIN
    END;
    FUNCTION  co_jugadorCercanos RETURN SYS_REFCURSOR;
    BEGIN
    END;
    FUNCTION  co_eventosGratis RETURN SYS_REFCURSOR;
    BEGIN
    END;
    FUNCTION  co_rangoJugador RETURN SYS_REFCURSOR;
    BEGIN
    END;
    FUNCTION  co_notificacionEvento RETURN SYS_REFCURSOR;
    BEGIN
    END;
END PA_Jugador;
/
/*-----------------------PA_EMPRESA------------------------------*/
CREATE OR REPLACE PACKAGE PA_EMPRESA IS
    PROCEDURE ad_representante(xIDRepresentante IN Varchar, xNumeroDocumento IN Varchar, xTipoDocumento IN Varchar, xNombre IN Varchar, xApellido IN Varchar);
    BEGIN
    END;
    FUNCTION  co_catalogo RETURN SYS_REFCURSOR;
    BEGIN
    END;
    FUNCTION  co_gruposRegion RETURN SYS_REFCURSOR;
    BEGIN
    END;
    FUNCTION  co_juegoMayorPuntaje RETURN SYS_REFCURSOR;
    BEGIN
    END;
    FUNCTION  co_ganadorEvento RETURN SYS_REFCURSOR;
    BEGIN
    END;
    FUNCTION  co_masJugado RETURN SYS_REFCURSOR;
    BEGIN
    END;
END PA_EMPRESA;
/
/*-----------------------PA_MODERADOR_TGAME------------------------------*/
CREATE OR REPLACE PACKAGE PA_MODERADOR_TGAME IS
    PROCEDURE el_juegosCatalgo(xNombre IN Varchar, IDCatalogo IN Varchar);
    BEGIN
    END;
    PROCEDURE el_eventos(xIDEvento IN Varchar, xNombreEvento IN Varchar);
    BEGIN
    END;
END PA_MODERADOR_TGAME;
/
/*-----------------------PA_GERENTE_TGAME------------------------------*/
CREATE OR REPLACE PACKAGE PA_GERENTE_TGAME IS
    FUNCTION  co_juegosMejorPunteados RETURN SYS_REFCURSOR;
    BEGIN
    END;
    FUNCTION  co_juegosPeorPunteados RETURN SYS_REFCURSOR; 
    BEGIN
    END;
    FUNCTION  co_catidadUsuarios RETURN SYS_REFCURSOR;
    BEGIN
    END;
    FUNCTION  co_eventosNoGratuitos RETURN SYS_REFCURSOR;
    BEGIN
    END;
    FUNCTION  co_dispositivoUsuario RETURN SYS_REFCURSOR;
    BEGIN
    END;
    FUNCTION  co_promedioEdad RETURN SYS_REFCURSOR;
    BEGIN
    END;
    FUNCTION  co_regionesActivas RETURN SYS_REFCURSOR;
    BEGIN
    END;
    FUNCTION  co_juegoEnEventos RETURN SYS_REFCURSOR;
    BEGIN
    END;
    FUNCTION  co_masGruposRegion RETURN SYS_REFCURSOR;
    BEGIN
    END;
    FUNCTION  co_cantidadEventosRepresentante RETURN SYS_REFCURSOR;
    BEGIN
    END;
END PA_GERENTE_TGAME;
/


