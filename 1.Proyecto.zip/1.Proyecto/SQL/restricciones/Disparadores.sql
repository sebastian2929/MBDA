/*---------------------------------Registra representantes---------------------------------*/
/*Disparadores*/
--Adicionar
CREATE OR REPLACE TRIGGER Tg_Ad_representantes
    BEFORE INSERT ON Representantes
    FOR EACH ROW
    DECLARE
        IDRepresentante  NUMBER;
        NumeroDocumento VARCHAR(50) ;
        TipoDocumento VARCHAR(50);
        Nombre VARCHAR(20) ;
        Apellido VARCHAR(20);
        representante NUMBER;
       
    BEGIN
        SELECT COUNT(IDRepresentante) into representante   FROM Representantes WHERE NumeroDocumento = :new.NumeroDocumento;
     
            IF (representante  > 0)
                THEN RAISE_APPLICATION_ERROR(-20201,'hay un representante registrado con ese nombre');
            END IF;
        IF (:new.Nombre is NULL)
            THEN :new.Nombre := 'Guest';
        END IF;
        IF (:new.Apellido is NULL)
            THEN :new.Apellido := 'Guest';
        END IF;
        IF (:new.TipoDocumento is NULL)
            THEN :new.TipoDocumento := 'CC';
        END IF;
END Tg_Ad_representantes;


/

--Modificar
CREATE OR REPLACE TRIGGER Tg_Mo_representantes
    BEFORE UPDATE ON Representantes
    FOR EACH ROW
    BEGIN
    IF (:old.IDRepresentante <> :new.IDRepresentante)
      
		THEN
			RAISE_APPLICATION_ERROR(-20202,'ACTUALIZACION NO PERMITIDA');
	    END IF; 

END Tg_Mo_representantes;
/
--eliminar
CREATE OR REPLACE TRIGGER Tg_El_representantes
	BEFORE DELETE ON representantes
	FOR EACH ROW
	BEGIN
		RAISE_APPLICATION_ERROR(-20203,'NO SE PUEDE ELIMINAR EL REPRESENTANTEs');
END Tg_El_representantes;
/

/*---------------------------------mantener grupo---------------------------------*/
/*Disparadores*/
--Adicionar
CREATE OR REPLACE TRIGGER Tg_Ad_Grupos
    BEFORE INSERT ON Grupos
    FOR EACH ROW
    DECLARE
        IDGrupo_prueba NUMBER;
        RangoGrupo NUMBER;

    BEGIN
     SELECT COUNT(NombreGrupo) into IDGrupo_prueba   FROM Grupos WHERE NombreGrupo = :new.NombreGrupo;
     
            IF (IDGrupo_prueba  > 0)
                THEN RAISE_APPLICATION_ERROR(-20201,'hay un grupo con ese nombre registrado con ese nombre');
            END IF;
    
    IF (:new.RangoGrupo is NULL)
            THEN :new.RangoGrupo := 1;
    END IF;

END Tg_Ad_Grupos;


/
--Modificar
CREATE OR REPLACE TRIGGER Tg_Mo_Grupos
    BEFORE UPDATE ON Grupos
    FOR EACH ROW
    BEGIN
    IF (:old.NombreGrupo <> :new.NombreGrupo) OR (:old.IDGrupo <> :new.IDGrupo)
      
		THEN
			RAISE_APPLICATION_ERROR(-20202,'ACTUALIZACION NO PERMITIDA');
	    END IF; 

END Tg_Mo_Grupos;

/
--eliminar
CREATE OR REPLACE TRIGGER Tg_El_Grupos
	BEFORE DELETE ON Grupos
	FOR EACH ROW
	BEGIN
		RAISE_APPLICATION_ERROR(-20203,'NO SE PUEDE ELIMINAR UN Grupos');
END Tg_El_representantes;

/



/*---------------------------------notificacion---------------------------------*/
/*Disparadores*/
--Adicionar
CREATE OR REPLACE TRIGGER Tg_Ad_Notificaciones
    BEFORE INSERT ON Notificaciones
    FOR EACH ROW
    DECLARE
        IDNotificacione NUMBER;
        Descripcion VARCHAR(500);
        prueb NUMBER;
    BEGIN
         IF (:new.Descripcion is NULL)
            THEN 
                RAISE_APPLICATION_ERROR(-20202,'mensaje no enviado');
        END IF;
        
END Tg_Ad_Notificaciones;


/

--Modificar
CREATE OR REPLACE TRIGGER Tg_Mo_Notificaciones
    BEFORE UPDATE ON Notificaciones
    FOR EACH ROW       
    BEGIN
    
        IF (:old.IDNotificacion <> :new.IDNotificacion) OR  (:old.IDLider <> :new.IDLider)
        OR  (:old.IDLider <> :new.IDLider)  OR  (:old.IDGrupo <> :new.IDGrupo)   OR  (:old.IDEvento <> :new.IDEvento) 
      
                THEN
                    RAISE_APPLICATION_ERROR(-20202,'ACTUALIZACION NO PERMITIDA');
	    END IF;
        

END Tg_Mo_Notificaciones;

/
--eliminar
CREATE OR REPLACE TRIGGER Tg_El_Notificaciones
	BEFORE DELETE ON Notificaciones
	FOR EACH ROW
	BEGIN
		RAISE_APPLICATION_ERROR(-20203,'NO SE PUEDE ELIMINAR UN EVENTO');
END Tg_El_Notificaciones;

/

/*---------------------------------eventos---------------------------------*/
/*Disparadores*/
--Adicionar
CREATE OR REPLACE TRIGGER Tg_Ad_Eventos
    BEFORE INSERT ON Eventos
    FOR EACH ROW
    DECLARE
        IDEventos NUMBER;
        NombreEvento_prueba VARCHAR(100) ;
        
        BEGIN
            SELECT COUNT(*) into NombreEvento_prueba   FROM Eventos WHERE NombreEvento = :new.NombreEvento;
     
            IF (NombreEvento_prueba  > 0)
                THEN RAISE_APPLICATION_ERROR(-20201,'hay un evento registrado con ese nombre');
            END IF;
    
END Tg_Ad_Eventos;

/
--Modificar
CREATE OR REPLACE TRIGGER Tg_Mo_Eventos
    BEFORE UPDATE ON Eventos
    FOR EACH ROW       
    BEGIN
    
        IF (:old.IDEvento <> :new.IDEvento) OR  (:old.NombreEvento <> :new.NombreEvento)  
      
                THEN
                    RAISE_APPLICATION_ERROR(-20202,'ACTUALIZACION NO PERMITIDA');
	    END IF;
        

END Tg_Mo_Eventos;

/
--eliminar
CREATE OR REPLACE TRIGGER Tg_El_Eventos
	BEFORE DELETE ON Eventos
	FOR EACH ROW
	BEGIN
		RAISE_APPLICATION_ERROR(-20203,'NO SE PUEDE ELIMINAR UN EVENTO');
END Tg_El_Eventos;

/
------------------catalogo-----------------------------
CREATE OR REPLACE TRIGGER Tg_Ad_Catalogos
    BEFORE INSERT ON Catalogos
    FOR EACH ROW
    DECLARE
        IDCatalogos  NUMBER;
        GeneroJuego VARCHAR(20);
        EdadMinima VARCHAR(3);
        Puntuacion NUMBER;
       
    BEGIN
        IF (:new.GeneroJuego is NULL)
            THEN :new.GeneroJuego := 'no definido';
        END IF;
        IF (:new.EdadMinima is NULL)
            THEN :new.EdadMinima := 10;
        END IF;
        IF (:new.Puntuacion is NULL)
            THEN :new.Puntuacion := 3;
        END IF;
END Tg_Ad_Catalogos;


/
--Modificar
CREATE OR REPLACE TRIGGER Tg_Mo_Catalogos
    BEFORE UPDATE ON Catalogos
    FOR EACH ROW
    BEGIN
    IF (:old.IDCatalogo <> :new.IDCatalogo)
      
		THEN
			RAISE_APPLICATION_ERROR(-20202,'ACTUALIZACION NO PERMITIDA');
	    END IF; 

END Tg_Mo_Catalogos;

/
--eliminar
CREATE OR REPLACE TRIGGER Tg_El_Catalogos
	BEFORE DELETE ON Catalogos
	FOR EACH ROW
	BEGIN
		RAISE_APPLICATION_ERROR(-20203,'NO SE PUEDE ELIMINAR EL catalogo');
END Tg_El_Catalogos;

/
--------------------------dispositivos----------
CREATE OR REPLACE TRIGGER Tg_Ad_Dispositivos
    BEFORE INSERT ON Dispositivos
    FOR EACH ROW
    DECLARE
        IDDispositivos  NUMBER;
        dispositivo VARCHAR(25);

       
    BEGIN
        IF (:new.dispositivo  is NULL)
            THEN RAISE_APPLICATION_ERROR(-20201,'NO HAY DISPOSITIVO');
        END IF;

END Tg_Ad_Dispositivos;


/
--Modificar
CREATE OR REPLACE TRIGGER Tg_Mo_Dispositivos
    BEFORE UPDATE ON Dispositivos
    FOR EACH ROW
    BEGIN
    IF (:old.IDDispositivo <> :new.IDDispositivo)
      
		THEN
			RAISE_APPLICATION_ERROR(-20202,'ACTUALIZACION NO PERMITIDA');
	    END IF; 

END Tg_Mo_Dispositivos;

/
--eliminar
CREATE OR REPLACE TRIGGER Tg_El_Dispositivos
	BEFORE DELETE ON Dispositivos
	FOR EACH ROW
	BEGIN
		RAISE_APPLICATION_ERROR(-20203,'NO SE PUEDE ELIMINAR EL Dispositivo');
END Tg_El_Dispositivos;

/


--------------------------jugadores----------
CREATE OR REPLACE TRIGGER Tg_Ad_Jugadores
    BEFORE INSERT ON Jugadores
    FOR EACH ROW
    DECLARE
        IDJugadores  NUMBER;
        RangoJugador NUMBER;

       
    BEGIN
        IF (:new.RangoJugador  is NULL)
            THEN :new.RangoJugador := 1;
        END IF;

END Tg_Ad_Jugadores;


/
--Modificar
CREATE OR REPLACE TRIGGER Tg_Mo_Jugadores
    BEFORE UPDATE ON Jugadores
    FOR EACH ROW
    BEGIN
    IF (:old.IDJugador <> :new.IDJugador)
      
		THEN
			RAISE_APPLICATION_ERROR(-20202,'ACTUALIZACION NO PERMITIDA');
	    END IF; 

END Tg_Mo_Jugadores;

/
--eliminar
CREATE OR REPLACE TRIGGER Tg_El_Jugadores
	BEFORE DELETE ON Jugadores
	FOR EACH ROW
	BEGIN
		RAISE_APPLICATION_ERROR(-20203,'NO SE PUEDE ELIMINAR EL jugador');
END Tg_El_Jugadores;

/


--------------------------usuario----------
CREATE OR REPLACE TRIGGER Tg_Ad_Usuarios
    BEFORE INSERT ON Usuarios
    FOR EACH ROW
    DECLARE
        IDJugadores  NUMBER;
        NombreUsuario VARCHAR(20);

       
    BEGIN
        IF (:new.NombreUsuario  is NULL)
            THEN :new.NombreUsuario := 'Guest';
        END IF;

END Tg_Ad_Usuarios;


/
--Modificar
CREATE OR REPLACE TRIGGER Tg_Mo_Usuarios
    BEFORE UPDATE ON Usuarios
    FOR EACH ROW
    BEGIN
    IF (:old.IDUsuario <> :new.IDUsuario) OR  (:old.NombreUsuario <> :new.NombreUsuario)
      
		THEN
			RAISE_APPLICATION_ERROR(-20202,'ACTUALIZACION NO PERMITIDA');
	    END IF; 

END Tg_Mo_Usuarios;

/
--eliminar
CREATE OR REPLACE TRIGGER Tg_El_Usuarios
	BEFORE DELETE ON Usuarios
	FOR EACH ROW
	BEGIN
		RAISE_APPLICATION_ERROR(-20203,'NO SE PUEDE ELIMINAR EL usuarioo');
END Tg_El_Usuarios;

/

--------------------------lider----------
CREATE OR REPLACE TRIGGER Tg_Ad_Lideres
    BEFORE INSERT ON Lideres
    FOR EACH ROW
    DECLARE
        IDLideres  NUMBER;


       
    BEGIN
        IF (:new.InicioLider  is NULL)
            THEN RAISE_APPLICATION_ERROR(-20203,'NO SE puede convertir en lider sin fecha de inicio');
        END IF;

END Tg_Ad_Usuarios;


/


--eliminar
CREATE OR REPLACE TRIGGER Tg_El_Lideres
	BEFORE DELETE ON Lideres
	FOR EACH ROW
	BEGIN
		RAISE_APPLICATION_ERROR(-20203,'NO SE PUEDE ELIMINAR EL LIder');
END Tg_El_Lideres;

/

--------------------------Empresas----------
CREATE OR REPLACE TRIGGER Tg_Ad_Empresas
    BEFORE INSERT ON Empresas
    FOR EACH ROW
       
    BEGIN
        IF (:new.Nombre  is NULL)
            THEN RAISE_APPLICATION_ERROR(-20203,'NO SE puede insertar la empresa');
        END IF;

END Tg_Ad_Empresas;


/
--------------------------Registros----------
CREATE OR REPLACE TRIGGER Tg_Ad_Registros
    BEFORE INSERT ON Registros
    FOR EACH ROW
       
    BEGIN
        IF (:new.NumeroDocumento  is NULL)
            THEN RAISE_APPLICATION_ERROR(-20203,'NO SE puede insertar el registro');
        END IF;

END Tg_Ad_Registros;

/

CREATE OR REPLACE TRIGGER Tg_Mo_Registros
    BEFORE UPDATE ON Registros
    FOR EACH ROW
    BEGIN
    IF (:old.IDRegistro <> :new.IDRegistro)
      
		THEN
			RAISE_APPLICATION_ERROR(-20202,'ACTUALIZACION NO PERMITIDA');
	    END IF; 

END Tg_Mo_Registros;

/
--eliminar
CREATE OR REPLACE TRIGGER Tg_El_Registros
	BEFORE DELETE ON Registros
	FOR EACH ROW
	BEGIN
		RAISE_APPLICATION_ERROR(-20203,'NO SE PUEDE ELIMINAR EL Registros');
END Tg_El_Registros;

/





