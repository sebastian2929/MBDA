/*---------------------------------Representante---------------------------------*/
/*Acciones de referencia*/
ALTER TABLE Catalogos DROP CONSTRAINT FK_Catalogos_Representantes;
ALTER TABLE Catalogos ADD CONSTRAINT FK_Catalogos_Representantes
FOREIGN KEY (IDRepresentante) REFERENCES Representantes(IDRepresentante) ON DELETE CASCADE;
