/*TUPLAS*/
ALTER TABLE Usuarios ADD CONSTRAINT CK_Usuarios_correo CHECK (REGEXP_LIKE(Correo, '(.+)\@(.+)\.(.+)'));
ALTER TABLE Notificaciones ADD CONSTRAINT CK_Notificaciones_correo CHECK (REGEXP_LIKE(CorreoLider, '(.+)\@(.+)\.(.+)'));
ALTER TABLE CorreoJugadores ADD CONSTRAINT CK_CorreoJugadores_correo CHECK (REGEXP_LIKE(CorreoJugador, '(.+)\@(.+)\.(.+)'));
ALTER TABLE Registros ADD CONSTRAINT CK_Registros_Genero CHECK (Genero IN ('M','F','O'));
ALTER TABLE Dispositivos ADD CONSTRAINT CK_Dispositivos_dispositivo CHECK (dispositivo IN ('Xbox', 'PlayStation', 'computador', 'Xbox y PlayStation', 'Xbox y computador',  'PlayStation y computador'));
ALTER TABLE Catalogos ADD CONSTRAINT CK_Catalogos_EdadMinima CHECK (EdadMinima IN ('0','10','15','18'));
ALTER TABLE Representantes ADD CONSTRAINT CK_Representantes_TipoDocumento CHECK (TipoDocumento IN ('RC', 'TI', 'CC', 'TE', 'CE', 'NIT', 'PASS'));
ALTER TABLE Registros ADD CONSTRAINT CK_Registros_TipoDocumento CHECK (TipoDocumento IN ('RC', 'TI', 'CC', 'TE', 'CE', 'NIT', 'PASS'));