/*TuplasNoOk*/
/*Se realiza un poblacion de muestra (PoblarNoOk)*/
/*Usuarios*/
insert into Usuarios (IDUsuario, NombreUsuario, Telefono, Correo, Contra) values (2000, 'cbrose0', '7127264596', 'sgrutjujiathis.com', 'JbquDROXm');
insert into Usuarios (IDUsuario, NombreUsuario, Telefono, Correo, Contra) values (2001, 'lchaffey1', '3981288850', 'jkobesheepurl.com', '93qMaIIiG8in');
insert into Usuarios (IDUsuario, NombreUsuario, Telefono, Correo, Contra) values (2002, 'tchadwyck2', '1305042840', 'tsummerliehamazon.de', 'Dz1XBMUqLV');
insert into Usuarios (IDUsuario, NombreUsuario, Telefono, Correo, Contra) values (2003, 'wsmitherham3', '1685569297', 'pferschke1delicious.com', 'ZIhYE9qYF4');
insert into Usuarios (IDUsuario, NombreUsuario, Telefono, Correo, Contra) values (2004, 'fpull4', '5016217397', 'acripps4xhatena.ne.jp', 'mGuZjWq');
insert into Usuarios (IDUsuario, NombreUsuario, Telefono, Correo, Contra) values (2005, 'btetford5', '8355884055', 'kmacfie4foxnews.com', '5vMDyrAucJc');

/*dispositivos*/
insert into Dispositivos (IDDispositivo, dispositivo) values (2100, 'PlayStations');
insert into Dispositivos (IDDispositivo, dispositivo) values (2101, 'PlayStation y computadors');
insert into Dispositivos (IDDispositivo, dispositivo) values (2102, 'Xboxs y PlayStation');
insert into Dispositivos (IDDispositivo, dispositivo) values (2103, 'computasdor');
insert into Dispositivos (IDDispositivo, dispositivo) values (2104, 'Xbox y PlaySstation');

/*Registros*/

insert into Registros (IDRegistro, NumeroDocumento, TipoDocumento, Nombre, Apellido, Genero, CodigoPostal, FechaNacimiento) values (2000000000, '2314126941', 'NI', 'Tibold', 'Shakelady', 'F', '110464', '13/4/1988');
insert into Registros (IDRegistro, NumeroDocumento, TipoDocumento, Nombre, Apellido, Genero, CodigoPostal, FechaNacimiento) values (2000000001, '6733509792', 'E', 'Vernor', 'Dewer', 'O', '558114', '22/7/1953');
insert into Registros (IDRegistro, NumeroDocumento, TipoDocumento, Nombre, Apellido, Genero, CodigoPostal, FechaNacimiento) values (2000000002, '5990926712', 'C', 'Wallie', 'Perrone', 'M', '674821', '28/2/1999');
insert into Registros (IDRegistro, NumeroDocumento, TipoDocumento, Nombre, Apellido, Genero, CodigoPostal, FechaNacimiento) values (2000000003, '6977787344', 'C', 'Gerry', 'Rock', 'M', '833736', '17/1/2019');
insert into Registros (IDRegistro, NumeroDocumento, TipoDocumento, Nombre, Apellido, Genero, CodigoPostal, FechaNacimiento) values (2000000004, '7650479184', 'qC', 'Myrah', 'Matysiak', 'M', '231110', '3/7/1953');
insert into Registros (IDRegistro, NumeroDocumento, TipoDocumento, Nombre, Apellido, Genero, CodigoPostal, FechaNacimiento) values (2000000005, '2725757227', 'I', 'Eba', 'Renfrew', 'O', '292821', '2/9/2014');

insert into Registros (IDRegistro, NumeroDocumento, TipoDocumento, Nombre, Apellido, Genero, CodigoPostal, FechaNacimiento) values (1000000000, '2314126941', 'NI', 'Tibold', 'Shakelady', 'S', '110464', '13/4/1988');
insert into Registros (IDRegistro, NumeroDocumento, TipoDocumento, Nombre, Apellido, Genero, CodigoPostal, FechaNacimiento) values (1000000001, '6733509792', 'E', 'Vernor', 'Dewer', 'R', '558114', '22/7/1953');
insert into Registros (IDRegistro, NumeroDocumento, TipoDocumento, Nombre, Apellido, Genero, CodigoPostal, FechaNacimiento) values (1000000002, '5990926712', 'C', 'Wallie', 'Perrone', 'W', '674821', '28/2/1999');
insert into Registros (IDRegistro, NumeroDocumento, TipoDocumento, Nombre, Apellido, Genero, CodigoPostal, FechaNacimiento) values (1000000003, '6977787344', 'C', 'Gerry', 'Rock', 'Q', '833736', '17/1/2019');
insert into Registros (IDRegistro, NumeroDocumento, TipoDocumento, Nombre, Apellido, Genero, CodigoPostal, FechaNacimiento) values (1000000004, '7650479184', 'qC', 'Myrah', 'Matysiak', 'M', '231110', '3/7/1953');
insert into Registros (IDRegistro, NumeroDocumento, TipoDocumento, Nombre, Apellido, Genero, CodigoPostal, FechaNacimiento) values (1000000005, '2725757227', 'I', 'Eba', 'Renfrew', 'W', '292821', '2/9/2014');


/*Representante*/
insert into Representantes (IDRepresentante, NumeroDocumento, TipoDocumento, Nombre, Apellido) values (10000, '0096772282', 'E', 'Dyann', 'Elecum');
insert into Representantes (IDRepresentante, NumeroDocumento, TipoDocumento, Nombre, Apellido) values (10001, '7399042070', 'T', 'Judith', 'Tatham');
insert into Representantes (IDRepresentante, NumeroDocumento, TipoDocumento, Nombre, Apellido) values (10002, '7948857511', 'TII', 'Ches', 'Ferrick');
insert into Representantes (IDRepresentante, NumeroDocumento, TipoDocumento, Nombre, Apellido) values (10003, '1144525984', 'CCC', 'Cad', 'Thing');
insert into Representantes (IDRepresentante, NumeroDocumento, TipoDocumento, Nombre, Apellido) values (10004, '5373598005', 'PASAS', 'Koressa', 'Rosberg');

/*ctalogo*/
insert into Catalogos (IDCatalogo, GeneroJuego, EdadMinima, Descripcion, Puntuacion, IDRepresentante) values (100000, 'Children|Drama', 1, 'quis justo', 5, 10000);
insert into Catalogos (IDCatalogo, GeneroJuego, EdadMinima, Descripcion, Puntuacion, IDRepresentante) values (100001, 'Documentary', 1, 'primis', 3, 10001);
insert into Catalogos (IDCatalogo, GeneroJuego, EdadMinima, Descripcion, Puntuacion, IDRepresentante) values (100002, 'Documentary', 2, 'leo maecenas', 1, 10002);
insert into Catalogos (IDCatalogo, GeneroJuego, EdadMinima, Descripcion, Puntuacion, IDRepresentante) values (100003, 'Comedy', 5, 'diam', 3, 10003);
insert into Catalogos (IDCatalogo, GeneroJuego, EdadMinima, Descripcion, Puntuacion, IDRepresentante) values (100004, 'Comedy|Crime|Drama', 6, 'quam suspendisse', 2, 10004);