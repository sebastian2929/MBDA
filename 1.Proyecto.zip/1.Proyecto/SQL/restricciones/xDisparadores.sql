
/*xDisparadores*/
drop Trigger Tg_Ad_representantes;
drop Trigger Tg_Mo_representantes;
drop Trigger Tg_El_representantes;
drop Trigger Tg_Ad_Grupos;
drop Trigger Tg_Mo_Grupos;
drop Trigger Tg_El_Grupos;
drop Trigger Tg_Ad_Notificaciones;
drop Trigger Tg_Mo_Notificaciones;
drop Trigger Tg_El_Notificaciones;
drop Trigger Tg_Ad_Eventos;
drop Trigger Tg_Mo_Eventos;
drop Trigger Tg_El_Eventos;
drop Trigger Tg_Ad_Catalogos;
drop Trigger Tg_Mo_Catalogos;
drop Trigger Tg_El_Catalogos;
drop Trigger Tg_Ad_Dispositivos;
drop Trigger Tg_Mo_Dispositivos;
drop Trigger Tg_El_Dispositivos;
drop Trigger Tg_Ad_Jugadores;
drop Trigger Tg_Mo_Jugadores;
drop Trigger Tg_El_Jugadores;
drop Trigger Tg_Ad_Usuarios;
drop Trigger Tg_Mo_Usuarios;
drop Trigger Tg_El_Usuarios;
drop Trigger Tg_Ad_Lideres;
drop Trigger Tg_El_Lideres;
drop Trigger Tg_El_Empresas;
drop Trigger Tg_AD_Empresas;
drop Trigger Tg_Ad_Registros;
drop Trigger Tg_El_Registros;
drop Trigger Tg_Mo_Registros;




