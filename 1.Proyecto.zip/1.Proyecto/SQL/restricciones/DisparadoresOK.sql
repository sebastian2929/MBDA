/*Usuarios*/ 
insert into Usuarios (IDUsuario, NombreUsuario, Telefono, Correo, Contra) values (1300, 'sebas', '3578722594', 'sebas@mac.com', 'tPfDHrfMSElm');
insert into Usuarios (IDUsuario, NombreUsuario, Telefono, Correo, Contra) values (1301, 'alcon123', '2592050224', 'alcon1239l@photobucket.com', 'actmfb6rMr0R');
insert into Usuarios (IDUsuario, NombreUsuario, Telefono, Correo, Contra) values (1402, 'ojos23', '8273915134', 'cmojos23@goodreads.com', 'Vn548I');

UPDATE Usuarios SET Telefono = 'Alex' WHERE NombreUsuario = 'sebas';
UPDATE Usuarios SET Contra = 'Ben' WHERE NombreUsuario = 'alcon123';
UPDATE Usuarios SET Telefono = 'Rmc' WHERE NombreUsuario = 'ojos23';

/*Empresas*/
/*adicionar*/
insert into Empresas (Nit, Nombre, IDUsuario) values ('167-032-67', 'ubisof', '1300');
insert into Empresas (Nit, Nombre, IDUsuario) values ('240-477-47', 'ativision', '1301');



/*---------------------------------Registra representantes---------------------------------*/
/*Adicionar*/
INSERT INTO Representantes (IDRepresentante, NumeroDocumento, TipoDocumento, Nombre, Apellido) VALUES (10100, '11339015','CC', 'Santiago', 'Perez');
INSERT INTO Representantes (IDRepresentante, NumeroDocumento, TipoDocumento, Nombre, Apellido) VALUES (10101, '111112223','CC', 'David', 'Rodriguez');


/*Modificar*/
UPDATE Representantes SET Nombre = 'Alex' WHERE IDRepresentante = 10100;
UPDATE Representantes SET Nombre = 'Ben' WHERE NumeroDocumento = '111112223';


/*---------------------------------grupo---------------------------------*/
/*Adicionar*/
insert into Grupos (IDGrupo, NombreGrupo, CantidadMiembros, RangoGrupo, MinRangoJugador, Descripcion, CodigoPostalGrupo) values (1000001201, 'jacro20', 10, 4, 6, 'dedicado a juefos de estrategia', '014334');
insert into Grupos (IDGrupo, NombreGrupo, CantidadMiembros, RangoGrupo, MinRangoJugador, Descripcion, CodigoPostalGrupo) values (1000002202, '12saAliqulidaor', 11, 9, 6, 'dedicado a juefos de  fantasia', '024354');
insert into Grupos (IDGrupo, NombreGrupo, CantidadMiembros, RangoGrupo, MinRangoJugador, Descripcion, CodigoPostalGrupo) values (1000003203, '12extremo', 2, 1, 3, 'dedicado a juegos de  accion', '021111');
/*Modificar*/
UPDATE Grupos SET Descripcion = 'Ganadores' WHERE IDGrupo = 1000000201;
UPDATE Grupos SET NombreGrupo = 'VENCEDORES' WHERE IDGrupo = 1000000202;
UPDATE Grupos SET NombreGrupo = 'ganadores' WHERE IDGrupo = 1000000203;

/*Registros*/
/*Adicionar*/
insert into Registros (IDRegistro, NumeroDocumento, TipoDocumento, Nombre, Apellido, Genero, CodigoPostal, FechaNacimiento) values (1000000000, '6833294960', 'NIT', 'Clarence', 'Glowacki', 'F', '685638', '10/3/1991');
insert into Registros (IDRegistro, NumeroDocumento, TipoDocumento, Nombre, Apellido, Genero, CodigoPostal, FechaNacimiento) values (1000000001, '2300703604', 'CE', 'Jo-anne', 'Batchley', 'F', '920627', '16/4/1977');
insert into Registros (IDRegistro, NumeroDocumento, TipoDocumento, Nombre, Apellido, Genero, CodigoPostal, FechaNacimiento) values (1000000002, '6367922346', 'TE', 'Eugen', 'Reide', 'F', '663501', '25/12/1939');

/*Catalogos*/
/*Adicionar*/
insert into Catalogos (IDCatalogo, GeneroJuego, EdadMinima, Descripcion, Puntuacion, IDRepresentante) values (100500, 'Crime', 18, 'nunc donec', 4, 10100);
insert into Catalogos (IDCatalogo, GeneroJuego, EdadMinima, Descripcion, Puntuacion, IDRepresentante) values (100501, 'fantasia', 10, 'mauris morbi', 1, 10101);

/*Modificar*/
UPDATE Catalogos SET Descripcion = 'Ganadores' WHERE IDCatalogo = 100500;
UPDATE Catalogos SET GeneroJuego = 'accion' WHERE IDCatalogo = 100501;
