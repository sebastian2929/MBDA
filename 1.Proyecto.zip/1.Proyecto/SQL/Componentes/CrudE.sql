CREATE OR REPLACE PACKAGE PC_LIDERES IS
    PROCEDURE ad_lider(xIDLider IN Varchar, xInicioLider IN Date);
    PROCEDURE el_lider(xIDLider IN Varchar);
    PROCEDURE ad_grupo(xIDGrupo IN Varchar, xNombreGrupo IN Varchar, xCantidadMiembros IN Number, xRangoGrupo IN Number, xMinRangoJugador IN Number);
    PROCEDURE mo_grupo(xNombreGrupo IN Varchar, xMinRangoJugador IN Number);
    PROCEDURE el_grupo(xIDGrupo IN Varchar, xNombreGrupo IN Varchar);
    PROCEDURE ad_notificacion(xIDNotificacion IN Varchar, xDescripcion IN Varchar, FechaEnvio IN Date, CorreoLider IN Varchar, IDLider IN Varchar, IDGrupo IN Varchar, IDEvento IN Varchar);
    PROCEDURE el_notificacion(xIDNotificacion IN Varchar);
    PROCEDURE ad_evento(xIDEvento IN Varchar, xNombreEvento IN Varchar, xFechaInicio IN Date, xFechaFin IN Date, xDescripcion IN Varchar, xPremio IN Varchar, xEquipoGanador IN Varchar, xMaxEquipos IN Number, xMinEquipos IN Number, xMaxRangoEquipo IN Number, xMinRangoEquipo IN Number);
    PROCEDURE mo_evento(xNombreEvento IN Varchar, xFechaInicio IN Date, xFechaFin IN Date, xDescripcion IN Varchar, xMaxEquipos IN Number, xMinEquipos IN Number, xMaxRangoEquipo IN Number, xMinRangoEquipo IN Number);
    PROCEDURE mo_evento(xNombreEvento IN Varchar, xFechaInicio IN Date, xFechaFin IN Date, xDescripcion IN Varchar, xMaxEquipos IN Number, xMinEquipos IN Number, xMaxRangoEquipo IN Number, xMinRangoEquipo IN Number);
    FUNCTION co_lideres RETURN  SYS_REFCURSOR;
    FUNCTION co_grupos RETURN  SYS_REFCURSOR;
    FUNCTION co_rangoGrupo RETURN  SYS_REFCURSOR;
    FUNCTION co_rangoJugadores RETURN  SYS_REFCURSOR;
    FUNCTION co_eventos RETURN  SYS_REFCURSOR;
    FUNCTION co_notificaciones RETURN  SYS_REFCURSOR;
    FUNCTION co_ganadorEvento RETURN  SYS_REFCURSOR;
END PC_LIDERES;
/
CREATE OR REPLACE PACKAGE PC_EVENTOS IS
    PROCEDURE ad_evento(xIDEvento IN Varchar, xNombreEvento IN Varchar, xFechaInicio IN Date, xFechaFin IN Date, xDescripcion IN Varchar, xPremio IN Varchar, xEquipoGanador IN Varchar, xMaxEquipos IN Number, xMinEquipos IN Number, xMaxRangoEquipo IN Number, xMinRangoEquipo IN Number);
    PROCEDURE mo_evento(xNombreEvento IN Varchar, xFechaInicio IN Date, xFechaFin IN Date, xDescripcion IN Varchar, xMaxEquipos IN Number, xMinEquipos IN Number, xMaxRangoEquipo IN Number, xMinRangoEquipo IN Number);
    PROCEDURE el_evento(xIDEvento IN Varchar, xNombreEvento IN Varchar);
    PROCEDURE ad_catalogo(xIDCatalogo IN Varchar, xGeneroJuego IN Varchar, xEdadMinima IN Number, xDescripcion IN Varchar, xIDRepresentante IN Varchar);
    PROCEDURE mo_catalogo(xGeneroJuego IN Varchar, xEdadMinima IN Number, xDescripcion IN Varchar);
    PROCEDURE el_catalogo(xIDCatalogo IN Varchar);
    FUNCTION co_eventos RETURN  SYS_REFCURSOR;
    FUNCTION co_catalogo RETURN  SYS_REFCURSOR;
    FUNCTION co_grupos RETURN  SYS_REFCURSOR;
    FUNCTION co_creadorEvento RETURN  SYS_REFCURSOR;
END PC_EVENTOS;
/
CREATE OR REPLACE PACKAGE PC_REPRESENTANTES IS
    PROCEDURE ad_catalogo(xIDCatalogo IN Varchar, xGeneroJuego IN Varchar, xEdadMinima IN Number, xDescripcion IN Varchar, xIDRepresentante IN Varchar);
    PROCEDURE ad_evento(xIDEvento IN Varchar, xNombreEvento IN Varchar, xFechaInicio IN Date, xFechaFin IN Date, xDescripcion IN Varchar, xPremio IN Varchar, xEquipoGanador IN Varchar, xMaxEquipos IN Number, xMinEquipos IN Number, xMaxRangoEquipo IN Number, xMinRangoEquipo IN Number);
    PROCEDURE el_evento(xIDEvento IN Varchar, xNombreEvento IN Varchar);
    PROCEDURE mo_catalogo(xGeneroJuego IN Varchar, xEdadMinima IN Number, xDescripcion IN Varchar);
    PROCEDURE el_catalogo(xIDCatalogo IN Varchar);
    PROCEDURE ad_representante(xIDRepresentante IN Varchar, xNumeroDocumento IN Varchar, xTipoDocumento IN Varchar, xNombre IN Varchar, xApellido IN Varchar);
    PROCEDURE el_representante(xIDRepresentante IN Varchar, xNombre IN Varchar, xApellido IN Varchar);
    FUNCTION co_catalogo RETURN  SYS_REFCURSOR;
    FUNCTION co_evento RETURN  SYS_REFCURSOR;
    FUNCTION co_representantes RETURN  SYS_REFCURSOR;
END PC_REPRESENTANTES;
/
CREATE OR REPLACE PACKAGE PC_USUARIOS IS
    PROCEDURE ad_usuario(xIDUsuario IN Varchar, xNombreUsuario IN Varchar, xTelefono IN Varchar, xCorreo IN Varchar, xConta IN Varchar);
    PROCEDURE mo_usuario(xNombreUsuario IN Varchar, xTelefono IN Varchar, xCorreo IN Varchar, xConta IN Varchar);
    PROCEDURE el_usuario(xIDUsuario IN Varchar);
    PROCEDURE ad_empresa(xNit IN Varchar, xNombre IN Varchar, xIDUsuario IN Varchar);
    PROCEDURE mo_empresa(xNombre IN Varchar);
    PROCEDURE el_empresa(xNit IN Varchar);
    PROCEDURE ad_jugador(xIDJugador IN Varchar, xRangoJugador IN Varchar, xDescripcionJugador IN Varchar, xIDRegistro IN Varchar, xIDGrupo IN Varchar);
    PROCEDURE el_jugador(xIDJugador IN Varchar);
    FUNCTION co_usuarios RETURN SYS_REFCURSOR;
    FUNCTION co_empresas RETURN SYS_REFCURSOR;
    FUNCTION co_jugadores RETURN SYS_REFCURSOR;
    FUNCTION co_eventoGanador RETURN SYS_REFCURSOR;
END PC_USUARIOS;
/