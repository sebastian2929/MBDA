
/*Unicas*/
ALTER TABLE usuarios ADD CONSTRAINT UK_usuarios UNIQUE (telefono,correo,NombreUsuario);
ALTER TABLE Videojuegos ADD CONSTRAINT UK_Videojuegos UNIQUE (NombreJuego);
ALTER TABLE Representantes ADD CONSTRAINT UK_Representantes UNIQUE (NumeroDocumento);
ALTER TABLE Eventos ADD CONSTRAINT UK_Evento UNIQUE (NombreEvento);
ALTER TABLE Registros ADD CONSTRAINT UK_Registros UNIQUE (NumeroDocumento);
ALTER TABLE Grupos ADD CONSTRAINT UK_Grupos UNIQUE (NombreGrupo);