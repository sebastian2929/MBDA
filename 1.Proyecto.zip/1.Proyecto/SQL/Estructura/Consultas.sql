/*CONSULTAS OPERATIVAS*/
/*Consultar el rango de un grupo*/
SELECT Grupos.RangoGrupo, Grupos.NombreGrupo
FROM Grupos
WHERE NombreGrupo = 'dbrouwer0';
/*Consultar la descripcion de un grupo*/
SELECT Grupos.Descripcion, Grupos.NombreGrupo
FROM Grupos
WHERE  NombreGrupo = 'sboote6';
/*Consultar los juegos del catalogo*/
SELECT VideoJuegos.NombreJuego AS nombre
FROM Videojuegos, Catalogos
WHERE VideoJuegos.IDCatalogo = Catalogos.IDCatalogo
ORDER BY nombre DESC;
/*Consultar los grupos que esten en la misma region*/
SELECT NombreGrupo
FROM Grupos
WHERE(CodigoPostalGrupo = '445781');
/*Consultar el rango de un jugador*/
SELECT Jugadores.RangoJugador, Usuarios.NombreUsuario
FROM Jugadores, Usuarios
WHERE Usuarios.NombreUsuario = 'bswabeyd';
/*Consulta los eventos gratuitos*/
SELECT NombreEvento
FROM Eventos
WHERE CostoEvento = 0
ORDER BY NombreEvento DESC;
/*Consula el grupo ganador de un evento*/
SELECT EquipoGanador
FROM Eventos
WHERE (NombreEvento = 'in libero ut');

