/*ESTRUCTURA*/
/*TABLAS*/
CREATE TABLE Usuarios(
    IDUsuario  NUMBER NOT NULL,
    NombreUsuario VARCHAR(50) NOT NULL,
    Telefono VARCHAR(50) NOT NULL,
    Correo VARCHAR(50) NOT NULL,
    Contra VARCHAR(50) NOT NULL
);

CREATE TABLE Jugadores(
    IDJugador  NUMBER NOT NULL,
    RangoJugador NUMBER NOT NULL,
    DescripcionJugador VARCHAR(500),
    IDRegistro  NUMBER NOT NULL,
    IDGrupo  NUMBER NOT NULL,
    IDUsuario NUMBER NOT NULL
);

CREATE TABLE Dispositivos(
    IDDispositivo  NUMBER NOT NULL,
    dispositivo VARCHAR(50) NOT NULL
);

CREATE TABLE Empresas(
    Nit VARCHAR(12) NOT NULL,
    Nombre VARCHAR(50) NOT NULL,
    IDUsuario  NUMBER NOT NULL
);

CREATE TABLE Videojuegos(
    IDJuego  NUMBER NOT NULL,
    NombreJuego VARCHAR(50) NOT NULL,
    NitEmpresa VARCHAR(12) NOT NULL,
    IDCatalogo NUMBER NOT NULL
);
CREATE TABLE Representantes(
    IDRepresentante  NUMBER NOT NULL,
    NumeroDocumento VARCHAR(50) NOT NULL,
    TipoDocumento VARCHAR(50) NOT NULL,
    Nombre VARCHAR(50) NOT NULL,
    Apellido VARCHAR(50) NOT NULL
);

CREATE TABLE Catalogos(
    IDCatalogo NUMBER NOT NULL,
    GeneroJuego VARCHAR(50) NOT NULL,
    EdadMinima VARCHAR(3) NOT NULL,
    Descripcion VARCHAR(500) NOT NULL,
    Puntuacion NUMBER NOT NULL,
    IDRepresentante  NUMBER NOT NULL
);

CREATE TABLE Eventos(
    IDEvento NUMBER NOT NULL,
    NombreEvento VARCHAR(50) NOT NULL,
    FechaInicio DATE NOT NULL,
    FechaFin DATE NOT NULL,
    Descripcion VARCHAR(500) NOT NULL,
    Premio VARCHAR(50) NOT NULL,
    EquipoGanador VARCHAR(50),
    MaxEquipos NUMBER NOT NULL,
    MinEquipos NUMBER NOT NULL,
    MaxRangoEquipo NUMBER NOT NULL,
    MinRangoEquipoo NUMBER NOT NULL,
    CostoEvento  NUMBER NOT NULL
);


CREATE TABLE Lideres(
    IDLider  NUMBER NOT NULL,
    InicioLider DATE NOT NULL,
    IDJugador NUMBER NOT NULL
);

CREATE TABLE Notificaciones(
    IDNotificacion NUMBER NOT NULL,
    Descripcion VARCHAR(500),
    FechaEnvio DATE NOT NULL,
    CorreoLider VARCHAR(50) NOT NULL,
    IDLider  NUMBER NOT NULL,
    IDGrupo  NUMBER NOT NULL,
    IDEvento NUMBER NOT NULL

);
CREATE TABLE CorreoJugadores(
    IDNotificacion NUMBER NOT NULL,
    CorreoJugador VARCHAR(50) NOT NULL
);

CREATE TABLE Registros(
    IDRegistro NUMBER NOT NULL,
    NumeroDocumento VARCHAR(50) NOT NULL,
    TipoDocumento VARCHAR(50) NOT NULL,
    Nombre VARCHAR(50) NOT NULL,
    Apellido VARCHAR(50) NOT NULL,
    Genero VARCHAR(50) NOT NULL,
    CodigoPostal VARCHAR(50) NOT NULL,
    FechaNacimiento DATE NOT NULL
);

CREATE TABLE Grupos(
    IDGrupo NUMBER NOT NULL,
    NombreGrupo VARCHAR(50) NOT NULL,
    CantidadMiembros NUMBER NOT NULL,
    RangoGrupo NUMBER NOT NULL,
    MinRangoJugador NUMBER NOT NULL,
    Descripcion VARCHAR(500),
    CodigoPostalGrupo VARCHAR(50) NOT NULL
);
CREATE TABLE Catalogos_Eventos(
    IDCatalogo NUMBER NOT NULL,
    IDEvento NUMBER NOT NULL
);
CREATE TABLE Grupos_Eventos(
    IDEvento NUMBER NOT NULL,
    IDGrupo NUMBER NOT NULL
);
CREATE TABLE Lideres_Eventos(
    IDEvento NUMBER NOT NULL,
    IDLider NUMBER NOT NULL
);
CREATE TABLE Empresas_Representantes(
    Nit VARCHAR(50) NOT NULL,
    IDRepresentante  NUMBER NOT NULL
);
CREATE TABLE Representantes_Eventos(
    IDRepresentante  NUMBER NOT NULL,
    IDEvento NUMBER NOT NULL
);
CREATE TABLE Lideres_Grupos(
    IDLider  NUMBER NOT NULL,
    IDGrupo NUMBER NOT NULL
);