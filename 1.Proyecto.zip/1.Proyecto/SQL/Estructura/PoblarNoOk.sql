/*Usuarios*/
insert into Usuarios (IDUsuario, NombreUsuario, Telefono, Correo, Contra) values (3000, 'rgyenes0', 3578724594, 'spickup5p@mac.com', 'tPfDHrfMSElm');
insert into Usuarios (IDUsuario, NombreUsuario, Telefono, Correo, Contra) values (3001, 'aschulaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaatz1', '2597050224', 'pschulkins9l@photobucket.com', 'actmfb6rMr0R');
insert into Usuarios (IDUsuario, NombreUsuario, Telefono, Correo, Contra) values (3002, 'dmetschke2', '8273945134', 'cma@ytomch@goodreads.com', 'Vn548I');
insert into Usuarios (IDUsuario, NombreUsuario, Telefono, Correo, Contra) values (3004, 'zianinotti4', '2464666748', 'mtiffinmv', 'MOOosPfnHy');

/*Empresas*/
insert into Empresas (Nit, Nombre, IDUsuario) values ('667-032-69', '1200');
insert into Empresas (Nit, Nombre, IDUsuario) values ('640-477-4634-345-345', 'Ebert, Gerhold and Koch', '1201');
insert into Empresas (Nit, Nombre, IDUsuario) values ('637-240-35', 'Fisher and Sons', '3000');
insert into Empresas (Nit, Nombre, IDUsuario) values ('Koss-Batz', '1203');
insert into Empresas (Nit, Nombre, IDUsuario) values ('352-962-21', 'Towne Inc');

/*Registros*/
insert into Registros (IDRegistro, NumeroDocumento, TipoDocumento, Nombre, Apellido, Genero, CodigoPostal, FechaNacimiento) values (2000000000, '6833294960', 'HOLA', 'Clarence', 'Glowacki', 'F', '685638', '10/3/1991');
insert into Registros (IDRegistro, NumeroDocumento, TipoDocumento, Nombre, Apellido, Genero, CodigoPostal, FechaNacimiento) values (2000000001, '2300703604', 'CE', 'Jo-anne', 'Batchley', 'F', '920627', '40/2040/19');
insert into Registros (IDRegistro, NumeroDocumento, TipoDocumento, Nombre, Apellido, Genero, CodigoPostal, FechaNacimiento) values (2000000002, '6367922346', 'TE', 'Eugen', 'Reide', 'F', '663501');
insert into Registros (IDRegistro, NumeroDocumento, TipoDocumento, Nombre, Apellido, Genero, CodigoPostal, FechaNacimiento) values (2000000003, '4701403105', 'NIT', 'Pace', 'Bernardot', 'F', '844051', '7/12/1939');
insert into Registros (IDRegistro, NumeroDocumento, TipoDocumento, Nombre, Apellido, Genero, CodigoPostal, FechaNacimiento) values (2000000004, 2023155486, 'TE', 'Cory', 'Fenning', 'F', '713919', '24/9/1988');

/*Grupos*/
insert into Grupos (IDGrupo, NombreGrupo, CantidadMiembros, RangoGrupo, MinRangoJugador, Descripcion, CodigoPostalGrupo) values (2000000000, 'dbrouwer0', 15, 10, 4, 'error: undefined method `/'' for nil:NilClass', 624455);
insert into Grupos (IDGrupo, NombreGrupo, CantidadMiembros, RangoGrupo, MinRangoJugador, Descripcion, CodigoPostalGrupo) values (2000000001, 'acoultass1', 18, 7, 'a', 'error: undefined method `/'' for nil:NilClass', '957235');
insert into Grupos (IDGrupo, NombreGrupo, CantidadMiembros, RangoGrupo, MinRangoJugador, Descripcion, CodigoPostalGrupo) values (2000000002, 'zlinnett2', 16, 'a', 9, 'error: undefined method `/'' for nil:NilClass', '248598');
insert into Grupos (IDGrupo, NombreGrupo, CantidadMiembros, RangoGrupo, MinRangoJugador, Descripcion, CodigoPostalGrupo) values (2000000003, 'lmcarthur3', 'aa', 2, 1, 'error: undefined method `/'' for nil:NilClass', '974040');
insert into Grupos (IDGrupo, NombreGrupo, CantidadMiembros, RangoGrupo, MinRangoJugador, Descripcion, CodigoPostalGrupo) values (2000000004, 'cbilson4', 13, 9, 'error: undefined method `/'' for nil:NilClass', '977183');

/*Jugadores*/
insert into Jugadores (IDJugador, RangoJugador, DescripcionJugador, IDRegistro, IDGrupo, IDUsuario) values (2100, 2, 'Suspendisse ornare consequat lectus. In est risus, auctor sed, tristique in, tempus sit amet, sem. Fusce consequat. Nulla nisl. Nunc nisl. Duis bibendum, felis sed interdum venenatis, turpis enim blandit mi, in porttitor pede justo eu massa. Donec dapibus. Duis at velit eu est congue elementum. In hac habitasse platea dictumst. Morbi vestibulum, velit id pretium iaculis, diam erat fermentum justo, nec condimentum neque sapien placerat ante.aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', 1000000000, 1000000053, 1000);
insert into Jugadores (IDJugador, RangoJugador, DescripcionJugador, IDRegistro, IDGrupo, IDUsuario) values (2103, 4, 'Sed accumsan felis. Ut at dolor quis odio consequat varius. Integer ac leo. Pellentesque ultrices mattis odio. Donec vitae nisi. Nam ultrices, libero non mattis pulvinar, nulla pede ullamcorper augue, a suscipit nulla elit ac nulla. Sed vel enim sit amet nunc viverra dapibus. Nulla suscipit ligula in lacus.', 1000000003, 1000000037, 4003);
insert into Jugadores (IDJugador, RangoJugador, DescripcionJugador, IDRegistro, IDGrupo, IDUsuario) values (2104, 4, 'Phasellus in felis. Donec semper sapien a libero. Nam dui. Proin leo odio, porttitor id, consequat in, consequat ut, nulla. Sed accumsan felis. Ut at dolor quis odio consequat varius. Integer ac leo. Pellentesque ultrices mattis odio.', 1000000004, 5000000024, 1004);

/*Representantes*/
insert into Representantes (IDRepresentante, NumeroDocumento, TipoDocumento, Nombre, Apellido) values (30000, 3327052881, 'CC', 'Jory', 'Coste');
insert into Representantes (IDRepresentante, NumeroDocumento, TipoDocumento, Nombre, Apellido) values (30001, '1127273490', 'TIAAA', 'Gian', 'Havvock');
insert into Representantes (IDRepresentante, NumeroDocumento, TipoDocumento, Nombre, Apellido) values (30002, '3075203052', 'TI', 'Daffie');
insert into Representantes (IDRepresentante, NumeroDocumento, TipoDocumento, Nombre, Apellido) values (30003, '7842199860', 'NIT','Camps');
insert into Representantes (IDRepresentante, NumeroDocumento, TipoDocumento, Nombre, Apellido) values (30004, 'CE', 'Allin', 'Stainer');

/*Lideres*/
insert into Lideres (IDLider, InicioLider, IDJugador) values ('2000', '12/4/2022', 1297);
insert into Lideres (IDLider, InicioLider, IDJugador) values (2001, 15/5/2022, 1157);
insert into Lideres (IDLider, InicioLider, IDJugador) values (2002, '23/6/2022', '1138');
insert into Lideres (IDLider, InicioLider, IDJugador) values (2003, '25/2/2022', 4000);
insert into Lideres (IDLider, InicioLider, IDJugador) values (2004, '20000/8/2022', 1135);

/*Dispositivos*/
insert into Dispositivos (IDDispositivo, dispositivo) values ('5100', 'Xbox y computador');
insert into Dispositivos (IDDispositivo, dispositivo) values (5101, 'casa');

/*Catalogos*/
insert into Catalogos (IDCatalogo, GeneroJuego, EdadMinima, Descripcion, Puntuacion, IDRepresentante) values ('200000', 'Crime|Drama', 18, 'nunc donec', 4, 10000);
insert into Catalogos (IDCatalogo, GeneroJuego, EdadMinima, Descripcion, Puntuacion, IDRepresentante) values (200001, 'Comedy|Drama', 0, 1, 10001);
insert into Catalogos (IDCatalogo, GeneroJuego, EdadMinima, Descripcion, Puntuacion, IDRepresentante) values (200002, 'Children|Comedy', 10, 'tincidunt', 5, 50000);
insert into Catalogos (IDCatalogo, GeneroJuego, EdadMinima, Descripcion, Puntuacion, IDRepresentante) values (200003, 'Drama', '0', 'placerat', 1, 10003);
insert into Catalogos (IDCatalogo, GeneroJuego, EdadMinima, Descripcion, Puntuacion, IDRepresentante) values (200004, 'Comedy|Romance', 0, 'a', 3, 10004);

/*VideoJuego*/
insert into Videojuegos (IDJuego, NombreJuego, NitEmpresa, IDCatalogo) values ('90', 'Excel', '044-576-33', 100000);
insert into Videojuegos (IDJuego, NombreJuego, NitEmpresa, IDCatalogo) values (91, 'LeSabre', 667-032-67, 100001);
insert into Videojuegos (IDJuego, NombreJuego, NitEmpresa, IDCatalogo) values (92, 'Sonata', '640-477-47', '100002');
insert into Videojuegos (IDJuego, NombreJuego, NitEmpresa, IDCatalogo) values (93, 'Grand Am', '637-240-33', 500003);
insert into Videojuegos (IDJuego, NombreJuego, NitEmpresa, IDCatalogo) values (94, 2, '697-197-88', 100004);

/*Eventos*/
insert into Eventos (IDEvento, NombreEvento, FechaInicio, FechaFin, Descripcion, Premio, EquipoGanador, MaxEquipos, MinEquipos, MaxRangoEquipo, MinRangoEquipoo, CostoEvento) values (2000000, 'tincidunt', '19/3/2022', '2022', 'sodales sed', 'dinero juego', null, 15, 3, 9, 3, 98495);
insert into Eventos (IDEvento, NombreEvento, FechaInicio, FechaFin, Descripcion, Premio, EquipoGanador, MaxEquipos, MinEquipos, MaxRangoEquipo, MinRangoEquipoo, CostoEvento) values ('2000001', 'duis aliquam', '16/6/2022', '22/2/2022', 'mauris laoreet', 'dinero juego', null, 8, 4, 7, 2, 58087);
insert into Eventos (IDEvento, NombreEvento, FechaInicio, FechaFin, Descripcion, Premio, EquipoGanador, MaxEquipos, MinEquipos, MaxRangoEquipo, MinRangoEquipoo, CostoEvento) values (2000002, 'porta volutpat erat', '13/3/2022', '24/8/2022', 'dinero juego', null, 8, 2, 10, 2, 58024);
insert into Eventos (IDEvento, NombreEvento, FechaInicio, FechaFin, Descripcion, Premio, EquipoGanador, MaxEquipos, MinEquipos, MaxRangoEquipo, MinRangoEquipoo, CostoEvento) values (2000003, 'pharetra', '14/1/2022', '3/2/2022', 'vulputate', 'viaje', null, 17, 2, 8, 3, '78530');
insert into Eventos (IDEvento, NombreEvento, FechaInicio, FechaFin, Descripcion, Premio, EquipoGanador, MaxEquipos, MinEquipos, MaxRangoEquipo, MinRangoEquipoo, CostoEvento) values (2000004, 'diam in', '21/1/2022', '21/4/2022', 'ut rhoncus', 'skill', null, 12, '2', 6, 1, 52814);

/*Notificaciones*/
insert into Notificaciones (IDNotificacion, Descripcion, FechaEnvio, CorreoLider, IDLider, IDGrupo, IDEvento) values ('20000000', 'scelerisque', '2/8/2022', 'hoosthoutdevreej1@people.com.cn', 1000, 1000000005, 1000069);
insert into Notificaciones (IDNotificacion, Descripcion, FechaEnvio, CorreoLider, IDLider, IDGrupo, IDEvento) values (20000001, 'ultrices', '2022', 'bmaidesi5@thetimes.co.uk', 1001, 1000000074, 1000076);
insert into Notificaciones (IDNotificacion, Descripcion, FechaEnvio, CorreoLider, IDLider, IDGrupo, IDEvento) values (20000002, 'neque', '30/12/2021', 'oalva@roo5@instagram.com', 1002, 1000000086, 1000002);
insert into Notificaciones (IDNotificacion, Descripcion, FechaEnvio, CorreoLider, IDLider, IDGrupo, IDEvento) values (20000003, 'erat', '16/9/2022', 'hsouthardgcom', 1003, 1000000023, 1000075);

/* CorreoJugadores */
insert into CorreoJugadores (IDNotificacion, CorreoJugador) values ('10000000', 'jshearn0@slideshare.net');
insert into CorreoJugadores (IDNotificacion, CorreoJugador) values (10000001, 'bredsall1yahoo.com');
insert into CorreoJugadores (IDNotificacion, CorreoJugador) values (10000002, 'spe@mbr@idge2@uol.com.br');
insert into CorreoJugadores (IDNotificacion, CorreoJugador) values (10000003, 'leivers3fr');
insert into CorreoJugadores (IDNotificacion, CorreoJugador) values (10000004);
