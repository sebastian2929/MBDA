/*Foraneas*/

ALTER TABLE Jugadores ADD CONSTRAINT FK_Jugadores_usuarios FOREIGN KEY (IDUsuario) REFERENCES usuarios(IDUsuario);
ALTER TABLE Jugadores ADD CONSTRAINT FK_Jugadores_Grupos FOREIGN KEY (IDGrupo) REFERENCES Grupos(IDGrupo);
ALTER TABLE Jugadores ADD CONSTRAINT FK_Jugadores_Registros FOREIGN KEY (IDRegistro) REFERENCES Registros(IDRegistro);

ALTER TABLE Dispositivos ADD CONSTRAINT FK_Dispositivos_Jugadores FOREIGN KEY (IDDispositivo) REFERENCES Jugadores(IDJugador);

ALTER TABLE Empresas ADD CONSTRAINT FK_Empresas_usuarios FOREIGN KEY (IDUsuario) REFERENCES usuarios(IDUsuario);

ALTER TABLE Videojuegos ADD CONSTRAINT FK_Videojuegos_Empresas FOREIGN KEY (NitEmpresa) REFERENCES Empresas(Nit);
ALTER TABLE Videojuegos ADD CONSTRAINT FK_Videojuegos_Catalogos FOREIGN KEY (IDCatalogo) REFERENCES Catalogos(IDCatalogo);

ALTER TABLE Catalogos ADD CONSTRAINT FK_Catalogos_Representantes FOREIGN KEY (IDRepresentante) REFERENCES Representantes(IDRepresentante);

ALTER TABLE Lideres ADD CONSTRAINT FK_Lideres_usuarios FOREIGN KEY (IDJugador) REFERENCES Jugadores(IDJugador);

ALTER TABLE Notificaciones ADD CONSTRAINT FK_Notificaciones_Lideres FOREIGN KEY (IDLider) REFERENCES Lideres(IDLider);
ALTER TABLE Notificaciones ADD CONSTRAINT FK_Notificaciones_Grupos FOREIGN KEY (IDGrupo) REFERENCES Grupos(IDGrupo);
ALTER TABLE Notificaciones ADD CONSTRAINT FK_Notificaciones_Eventos FOREIGN KEY (IDEvento) REFERENCES Eventos(IDEvento);

ALTER TABLE CorreoJugadores ADD CONSTRAINT FK_CorreoJugadores_Notificaciones FOREIGN KEY (IDNotificacion) REFERENCES Notificaciones(IDNotificacion);

ALTER TABLE Catalogos_Eventos ADD CONSTRAINT FK_Catalogos_Eventos FOREIGN KEY (IDCatalogo) REFERENCES Catalogos(IDCatalogo);
ALTER TABLE Catalogos_Eventos ADD CONSTRAINT FK_EventosCatalogos FOREIGN KEY (IDEvento) REFERENCES Eventos(IDEvento);

ALTER TABLE Grupos_Eventos ADD CONSTRAINT FK_Grupos_Eventos FOREIGN KEY (IDEvento) REFERENCES Eventos(IDEvento);
ALTER TABLE Grupos_Eventos ADD CONSTRAINT FK_Eventos_Grupos FOREIGN KEY (IDGrupo) REFERENCES Grupos(IDGrupo);

ALTER TABLE Lideres_Eventos ADD CONSTRAINT FK_Lideres_Eventos FOREIGN KEY (IDLider) REFERENCES Lideres(IDLider);
ALTER TABLE Lideres_Eventos ADD CONSTRAINT FK_Eventos_Lideres FOREIGN KEY (IDEvento) REFERENCES Eventos(IDEvento);

ALTER TABLE Empresas_Representantes ADD CONSTRAINT FK_Empresas_Representantes FOREIGN KEY (Nit) REFERENCES Empresas(Nit);
ALTER TABLE Empresas_Representantes ADD CONSTRAINT FK_Representantes_Empresas FOREIGN KEY (IDRepresentante) REFERENCES Representantes(IDRepresentante);

ALTER TABLE Representantes_Eventos ADD CONSTRAINT FK_Representantes_Eventos FOREIGN KEY (IDRepresentante) REFERENCES Representantes(IDRepresentante);
ALTER TABLE Representantes_Eventos ADD CONSTRAINT FK_Eventos_Representantes FOREIGN KEY (IDEvento) REFERENCES Eventos(IDEvento);

ALTER TABLE Lideres_Grupos ADD CONSTRAINT FK_Lideres_Grupos FOREIGN KEY (IDLider) REFERENCES Lideres(IDLider);
ALTER TABLE Lideres_Grupos ADD CONSTRAINT FK_Grupos_Lideres FOREIGN KEY (IDGrupo) REFERENCES Grupos(IDGrupo);